<?php

namespace Database\Factories;

use App\Models\CustomerServiceReview;
use Illuminate\Database\Eloquent\Factories\Factory;

class CustomerServiceReviewFactory extends Factory
{
    protected $model = CustomerServiceReview::class;

    public function definition(): array
    {
    	return [
    	    //
    	];
    }
}
