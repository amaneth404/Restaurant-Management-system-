<?php

namespace Database\Factories;

use App\Models\CustomerServiceLog;
use Illuminate\Database\Eloquent\Factories\Factory;

class CustomerServiceLogFactory extends Factory
{
    protected $model = CustomerServiceLog::class;

    public function definition(): array
    {
    	return [
    	    //
    	];
    }
}
