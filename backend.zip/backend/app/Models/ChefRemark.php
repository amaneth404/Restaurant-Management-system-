<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChefRemark extends Model
{
    //
}
