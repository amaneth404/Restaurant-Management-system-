<?php

namespace App\Http\Controllers\Category\CategoryRules;


class CategoryRules
{
    const CategoryStoreRule=[
        'title'=>'required|unique:categories'
    ];
    public static function CategoryUpdateRule($id){
        return [
        'title'=>'required|unique:categories,title,'.$id,
    ];
}
}


