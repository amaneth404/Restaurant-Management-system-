<?php

namespace App\Http\Controllers\Casher;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Casher;
use App\Models\User;
use App\Models\Credit;
use App\Models\reporttr;
use App\Models\Order;
use App\Models\item;
use App\Models\storeRequest;
use App\Models\RequestItemFolder;
use App\Http\Controllers\Item\ItemController;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Casher\CasherRules\CasherRules;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use App\Models\bank;
use App\Services\FileService;
use Illuminate\Support\Facades\DB;
class CasherController extends Controller
{
    public function index(Request $request,$user_id,$type=0){
        $holder=[];
        
        $given=[0];
        if($request->isfilter){
            $given=[0,1];
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>',$now],
                ['created_at','<',$after]
            ];
        }
        $Casher=null;
        $user_id=($user_id=='undefined'?'':$user_id);
        if($user_id){
            $holder[]=['waiter','=',$user_id];
        }else{
            $holder[]=['waiter','!=',null];
        }
        // return [$user_id,'aman'];      
        if($type==0){
            $Casher=Casher::whereIn('state',[1,-1])->where($holder)->where('credit',0)->where('is_gift',0)->whereIN('given',$given)->where('isflaged',0)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders','waiter')->get();
        }else if($type==1){
            $Casher=Casher::whereIn('state',[1,-1])->where($holder)->where('credit',0)->where('is_gift',0)->whereIN('given',$given)->where('isflaged',1)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders','waiter')->get();
        }else if($type==2){
            $Casher=Casher::where($holder)->whereIN('given',$given)->where('isflaged',0)->where('credit',0)->where('is_gift',0)->where('state',0)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders','waiter')->get();
        }else if($type==3){
            $Casher=Casher::where($holder)->whereIN('given',$given)->where('isflaged',0)->where('credit',0)->where('is_gift',1)->where('state',0)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders','waiter')->get();
        }else if($type==4){
            $Casher=Casher::where($holder)->whereIN('given',$given)->where('isflaged',0)->where('credit','!=',0)->where('is_gift',0)->where('state',0)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders','waiter')->get();
        }

        return $this->SuccessResponse($Casher,200);
    }
    
    public function GroupedOrder(){
        $date=Carbon::now()->addDay(1);
        $after=Carbon::parse(explode(' ',$date)[0].' 00:00');
        $now=Carbon::parse(explode(' ',$after)[0].' 00:00')->subDays(1);
        $Casher = Casher::where('isdone', 0)
        ->where('tokichen', 1)
        ->where('created_at', '>=', $now)
        ->where('isflaged', 0)
        ->with('menu','waiter')
        ->select('orders','waiter','folder_id', DB::raw('count(*) as total'),DB::raw('max(remark) as remark')) // Group and concatenate ids
        ->groupBy('orders','folder_id','waiter')
        ->orderBy('created_at')
        ->get();
         return $Casher;
    }
    public function GroupedOrderDone(){
        $date=Carbon::now()->addDay(1);
        $after=Carbon::parse(explode(' ',$date)[0].' 00:00');
        $now=Carbon::parse(explode(' ',$after)[0].' 00:00')->subDays(1);
        $Casher = Casher::where('isdone', 1)
        ->where('tokichen', 1)
        ->where('created_at', '>=', $now)
        ->where('isflaged', 0)
        ->with('menu','waiter')
        ->select('orders','waiter','folder_id', DB::raw('count(*) as total'),DB::raw('max(remark) as remark')) // Group and concatenate ids
        ->groupBy('orders','folder_id','waiter')
        ->orderBy('done_time')
        ->get();
         return $Casher;
    }
    public function Chefeindex(){
            $date=Carbon::now()->addDay(1);
            $after=Carbon::parse(explode(' ',$date)[0].' 00:00');
            $now=Carbon::parse(explode(' ',$after)[0].' 00:00')->subDays(1);
            $Casher=Casher::where('isdone',0)->where('tokichen',1)->where('created_at','>=',$now)->with('menu')->where('isflaged',0)->with('waiter')->orderBy('created_at')->get();
            return $Casher->last();
            $last_id=0;
            if(count($Casher)){
            $last_id = $Casher->last()->created_at;
            }
            return $this->SuccessResponse($last_id,200);
    }
    public function Chefeindexadmin(){
        $date = Carbon::now()->addDay(1);
        $after = Carbon::parse(explode(' ', $date)[0] . ' 00:00');
        $now = Carbon::parse(explode(' ', $after)[0] . ' 00:00')->subDays(2);
        
        $Casher = Casher::where('isdone', 1)
            ->where('tokichen', 1)
            ->where('created_at', '>=', $now)
            ->where('isflaged', 0)
            ->with(['menu', 'waiter'])
            ->select(
                'orders',
                'waiter',
                'folder_id', 
                DB::raw('count(*) as total'), 
                DB::raw('max(remark) as remark'), 
                DB::raw('MAX(created_at) as last_created_at'), 
                DB::raw('MAX(done_time) as last_done_time'),
                DB::raw("TIMESTAMPDIFF(MINUTE, MAX(created_at), MAX(done_time)) AS time_diff") // Corrected TIMESTAMPDIFF usage
            )
            ->groupBy('orders', 'folder_id', 'waiter')
            ->orderBy('last_created_at')
            ->paginate(100);
        return $this->SuccessResponse($Casher,200);
    }
    public function ChefDone($id){
        $Order=Casher::findOrfail($id);
        $Order->done_time=Carbon::now();
        $Order->isdone=1;
        $Order->save();
        return $Order;
    }
    public function ChefDoneAll($id){
        $Casher=Casher::where('folder_id',$id)->update(['isdone'=>1,'done_time'=>Carbon::now()]);
    }
    public function PayedOrders(){
        $Casher=Casher::where('state',0)->where('isdelivery',0)->orderBy('created_at', 'desc')->with('waiter','menu')->get();
        return $this->SuccessResponse($Casher,200);
    }
    public function FlagedOrdersAll(){
        $Casher=Casher::where('isflaged',1)->where('isdelivery',0)->orderBy('created_at', 'desc')->with('waiter','menu')->get();
        return $this->SuccessResponse($Casher,200);
    }
    public function deliveryPayedOrders(){
        $Casher=Casher::where('state',0)->where('isdelivery',1)->orderBy('created_at', 'desc')->with('waiter','menu')->get();
        return $this->SuccessResponse($Casher,200);
    }
    public function deliveryFlagedOrdersAll(){
        $Casher=Casher::where('isflaged',1)->where('isdelivery',1)->orderBy('created_at', 'desc')->with('waiter','menu')->get();
        return $this->SuccessResponse($Casher,200);
    }
   
    public function Payed(Request $request){
        $recipt=0;
        for($i=0;$i<count($request->orders);$i++){
        $id=$request->orders[$i]['orders'];
        $numbers=$request->orders[$i]['number'];
        $today=Carbon::today();
        $Cashers=Casher::where('orders',$id)->where('created_at','>=',$today)->where('state','!=',0)->limit($numbers)->get();
        foreach($Cashers as $Casher){
        if($Casher){
            $Casher->state=0;
            if($request->type&&$Casher->credit==0){
            $Casher->credit=-1;
            (new Credit)->StoreCredit($Casher->waiter,$Casher->price,$request->full_name,$request->phone_number);
            }
            if($Casher->credit>0){
                $user=User::findOrfail($Casher->credit);
                $user->credit+=$Casher->price;
                $user->save();
            }
            $Casher->aut_id=Auth::user()->id;
            if($recipt==0){
                if($request->bank){
                    $recipt=1;
                    $Casher->bank_money=$request->money;
                }
            }
            $Casher->bank=$request->bank;
            $Casher->save();
        }
    }
}
        return $this->SuccessResponse('success',200);
    }
    public function getCasherReport(Request $request){
        $holder=[];
        
        $given=[0];
        if($request->isfilter){
            $given=[0,1];
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>=',$now],
                ['created_at','<',$after]
            ];
        }
        $cashers=Casher::select('aut_id',DB::raw('sum(price) as price'))->where([['state','=',0,'or'],['state','=',-10,'or']])->where('isflaged',0)->where($holder)->where('state',0)->whereIN('given',$given)->with('User')->wherenotNull('aut_id')->groupBy('aut_id')->get();
        foreach($cashers as $casher){
            $casher['credit']=Casher::where('aut_id',$casher->aut_id)->where('isflaged',0)->where('state',0)->whereIN('given',$given)->where($holder)->where('credit','!=','0')->sum('price');
            $casher['gift']=Casher::where('state',0)->where('is_gift',1)->where('isflaged',0)->whereIN('given',$given)->where($holder)->where('aut_id',$casher->aut_id)->sum('price');
            $casher['bank']=Casher::where('aut_id',$casher->aut_id)->where('isflaged',0)->where('state',-10)->where($holder)->whereIN('given',$given)->wherenotnull('bank')->sum('bank_money');
            $casher['paid']=Credit::where('casher',$casher->aut_id)->whereIN('given',$given)->where('state',1)->where($holder)->sum('paid');
            $casher['credit']+=Credit::where('casher',$casher->aut_id)->whereIN('given',$given)->where('state',0)->where($holder)->sum('money');
            $casher['credit']+=Credit::where('casher',$casher->aut_id)->whereIN('given',$given)->where('state',6)->where($holder)->sum('money');
            $casher['owner_gift']=Credit::where('casher',$casher->aut_id)->whereIN('given',$given)->where('state',4)->where($holder)->sum('money');
            $casher['waiter_credit']=Credit::where('casher',$casher->aut_id)->whereIN('given',$given)->where('state',5)->where($holder)->sum('money');



        }
        return $cashers;
    }
    public function UpdateBank(Request $request){
        $Casher=new Casher;
        $Casher->id=Str::uuid();
       
        $Casher->folder_id=Str::uuid();
        $Casher->credit=0;
       
        $Casher->is_gift=0;
        $Casher->index_holder=0;
        $Casher->orders= '';
        $Casher->waiter=$request->user_id;
        $Casher->table_name=0;
        $Casher->amount=1;
        $Casher->aut_id=Auth::user()->id;
        $Casher->state=-10;
        $Casher->price=0;
        $Casher->tokichen=0;
        $Casher->bank=$request->bank_id;
        $Casher->bank_money=$request->money;
        $Casher->save();
        $Casher['user']=Auth::user();
        $Casher['waiter']=User::findOrfail($request->waiter);
        return $Casher;
    }
    public function Given($id){
        Casher::where('aut_id',$id)->where('given',0)->update(['given'=>1]);
        Credit::where('casher',$id)->where('given',0)->update(['given'=>1]);
    }
    public function getWaiterReport(Request $request){
        $holder=[];
        
        $given=[0];
        if($request->isfilter){
            $given=[0,1];
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>=',$now],
                ['created_at','<',$after]
            ];
        }
        $cashers=Casher::select('waiter',DB::raw('sum(price) as price'))->where('isflaged',0)->where($holder)->where([['state','=',0,'or'],['state','=',-10,'or']])->whereIN('given',$given)->whereIN('w_given',$given)->with('waiter')->wherenotNull('waiter')->groupBy('waiter')->get();
        foreach($cashers as $casher){
            $casher['credit']=Casher::where('waiter',$casher->waiter)->where($holder)->where('isflaged',0)->whereIN('w_given',$given)->where('state',0)->whereIN('given',$given)->where('credit','!=','0')->sum('price');
            $casher['credit']+=Credit::where('waiter',$casher->waiter)->where($holder)->whereIN('w_given',$given)->whereIN('given',$given)->where('state',0)->sum('money');
            $casher['credit_w']=Credit::where('user_id',$casher->waiter)->where($holder)->whereIN('w_given',$given)->whereIN('given',$given)->whereIn('state',[5,6])->sum('money');
            $casher['gift_w']=Credit::where('waiter',$casher->waiter)->where($holder)->whereIN('w_given',$given)->whereIN('given',$given)->where('state',4)->sum('money');
            $casher['gift']=Casher::where('state',0)->where('isflaged',0)->where($holder)->where('is_gift',1)->whereIN('given',$given)->whereIN('w_given',$given)->where('waiter',$casher->waiter)->sum('price');
            $casher['bank']=Casher::where('waiter',$casher->waiter)->where($holder)->where('isflaged',0)->whereIN('w_given',$given)->where('state',-10)->whereIN('given',$given)->wherenotnull('bank')->sum('bank_money');
        }
        return $cashers;
    }
    public function WaiterGiven(Request $request,$id){
        
        Casher::where('waiter',$id)->where('w_given',0)->update(['w_given'=>1]);
        Credit::where('waiter',$id)->where('w_given',0)->update(['w_given'=>1]);
        Credit::where('user_id',$id)->where('w_given',0)->update(['w_given'=>1]);
       
       
    }
    

    public function FlagedOrders(){
        $Casher=Casher::whereIn('state',0)->where('given',0)->where('isflaged',1)->with('menu')->with('waiter')->select('orders as orders',DB::raw('count(*) as total'),DB::raw('0 as number'),DB::raw('sum(price) as price'),DB::raw('Max(waiter) as waiter'))->groupBy('orders')->get();

        // $Casher=Casher::whereIn('state',[1,-1])->where('isflaged',1)->with('waiter')->orderBy('created_at', 'desc')->paginate(100);
        return $this->SuccessResponse($Casher,200);
    }
    public function CasherWithOrder($id){
        $Casher=Casher::where('id',$id)->with(['waiter','order'=>function($qurery){
            $qurery->with('menu')->get();
        }])->orderBy('created_at', 'desc')->first();
        return $this->SuccessResponse($Casher,200);
    }
    public function Search(Request $request){
        $Casher=Casher::where('table_name','like','%'.$request->search.'%')->where('state',1)->with('waiter')->orderBy('created_at', 'desc')->paginate(100);
        return $this->SuccessResponse($Casher,200);
    }
    public function store(Request $request){
        $this->validate($request,CasherRules::CasherStoreRule);
        $waiter=null;
        $order_holder=[];
        $store_order=[];
        $waiter=User::findOrfail($request->waiter);
        $counter=1;
        foreach($request->order as $ord){
        $holder=[];
        $casher_h=null;
        $folder_id=Str::uuid();
        $remark=$ord['remark'];
            for($i=0;$i<$ord['order']*1;$i++){
            $Casher=new Casher;
        $Casher->id=Str::uuid();
        if($i==0){
            $Casher->remark=$remark;
        }
        $Casher->folder_id=$folder_id;
        $Casher->credit=$request->credit?$request->credit:0;
        if($request->credit){
            $user=User::findOrfail($request->credit);
            $user->credit+=$ord['menu']['price'];
            $user->save();
        }
        $Casher->is_gift=$request->is_gift?1:0;
        $Casher->index_holder='natna/';
        $Casher->orders= ($ord['menu']['menu_id']==-1?$ord['menu']['name']:$ord['menu']['menu_id']);
        $Casher->waiter=$request->waiter;
        $Casher->table_name=0;
        $Casher->amount=1;
        $Casher->aut_id=Auth::user()->id;
        $Casher->state=0;
        $Casher->price=$ord['menu']['price'];
        $Casher->tokichen=$ord['menu']['tokichen'];
        $Casher->save();
        $counter++;
            if($ord['menu']['menu_id']==-1){
                $Casher->menu;
                $order_holder[]= $Casher;
            }else{
                $Casher->menu;
                if($ord['menu']['item_id']){
                    // $ord['order']=1;
                    $casher_h=$Casher;
                    $this->RequestToStore($casher_h->id,[$ord]);
                    $holder[]=$ord;
                    $store_order[]=$Casher;
                }else{
                    $order_holder[]=$Casher;
                }
            }
        }
        
        

        }
        return $this->SuccessResponse($counter,200);
    }
    private function RequestToStore($id,$request){
        $RequestItemFolder=RequestItemFolder::where('state',-1)->where('chaser_id',$id)->first();
        if($RequestItemFolder){
            foreach($request as $req){
            $storeRequest=new storeRequest;
            $storeRequest->id=Str::uuid();
            $storeRequest->item_id=$req['menu']['item_id'];
            $storeRequest->amount=$req['menu']['mul']*1;
            $storeRequest->folder_id=$RequestItemFolder->id;
            $storeRequest->save();
            $request=new Request;
            $request->merge(['amount'=>$req['menu']['mul']*1,'to'=>1]);
            (new ItemController)->transfer($request,$storeRequest->item_id);
            }
        }else{
            $RequestItemFolder=new RequestItemFolder;
            $RequestItemFolder->id=Str::uuid();
            $RequestItemFolder->state=1;
            $RequestItemFolder->chaser_id=$id;
            $RequestItemFolder->save();
            foreach($request as $req){
            $storeRequest=new storeRequest;
            $storeRequest->id=Str::uuid();
            $storeRequest->item_id=$req['menu']['item_id'];
            $storeRequest->amount=$req['menu']['mul']*1;
            $storeRequest->folder_id=$RequestItemFolder->id;
            $storeRequest->save();
            $request=new Request;
            $request->merge(['amount'=>$req['menu']['mul']*1,'to'=>1]);
            (new ItemController)->transfer($request,$storeRequest->item_id);
            }
        }
        return 'success';
    }
    public function update(Request $request){
        $Casher=Casher::findOrfail($request->id);
        $this->validate($request,CasherRules::CasherUpdateRule($Casher->id));
        $price=0;
        $counter=0;
        foreach($request->order as $ord){
            $price+=$ord['menu']['price']*$ord['order'];
            $counter+=$ord['order'];
        }
        $waiter=null;
        $price+=$Casher->price;
        if($request->isdelivery==1){
            $price+=0;
            $price+=$request->fee-$Casher->fee;
            $Casher->isdelivery=1;
            $Casher->fee=$request->fee;
            $Casher->box=0;
        }else{
            $user=User::findOrfail($request->waiter);
            $waiter=$user;
            $Casher->waiter=$request->waiter;
        $Casher->table_name=$request->table_name;
        $Casher->isdelivery=0;
        }
        $Casher->orders+=$counter;
        $Casher->price=$price;
        $Casher->save();
        $holder=[];
        $order_holder=[];
        $store_order=[];
        foreach($request->order as $ord){
            if($ord['menu']['menu_id']==-1){
                $tester= Order::create(['id'=>Str::uuid(),'casher_id'=>$Casher->id,'price'=>$ord['menu']['price'],'amount'=>$ord['order'],'order'=>$ord['menu']['name']]);
                $tester->menu;
                $order_holder[]= $tester;
            }else{
                $holder_data=Order::create(['id'=>Str::uuid(),'casher_id'=>$Casher->id,'menu_id'=>$ord['menu']['menu_id'],'amount'=>$ord['order'],'price'=>$ord['menu']['price']]);
                $holder_data->menu;
                if($ord['menu']['item_id']){
                    $holder[]=$ord;
                    $store_order[]=$holder_data;
                }else{
                    $order_holder[]=$holder_data;
                }
            }
        }
        if(count($holder)>0)
        $this->RequestToStore($Casher->id,$holder);
        $Casher['waiter']=$waiter;
        $Casher['order']=$order_holder;
        $Casher['store']=$store_order;
        return $this->successResponse($Casher,200);
    }
    public function destroy($id){
        $Casher=Casher::findOrfail($id);
        $Casher->delete();
        return $this->SuccessResponse(['message'=>['Successfully deleted']],200);
    }
    public function Flag(Request $request){
        $id=$request->orders;
        $numbers=$request->numbers;
        $isgiven=$request->given;
        $holder=[];
        
        if($request->isfilter){
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>',$now],
                ['created_at','<',$after]
            ];
        }
        $Cashers=Casher::where('waiter',$request->waiter)->where('orders',$id)->where($holder)->where('given',$isgiven)->where('state',0)->where('credit',0)->where('is_gift',0)->wherenull('bank')->where('isflaged',0)->limit($numbers)->get();
        foreach($Cashers as $Casher){
        $Casher->isflaged=1;
        $Casher->save();
        $RequestItemFolder=RequestItemFolder::where('state',1)->where('chaser_id',$Casher->id)->first();
        if($RequestItemFolder){
            $storeRequest=storeRequest::where('folder_id',$RequestItemFolder->id)->limit($numbers)->first();
            $item=item::findOrfail($storeRequest->item_id);
            $item->sold-=$storeRequest->amount*$Casher->amount;
            $item->save();
            $reporttr=reporttr::where('items',$item->id)->where('amount',$storeRequest->amount)->where('type',1)->latest()->first();
            $reporttr->delete();
            $storeRequest->delete();
            $RequestItemFolder->delete();
        }
    

}
        return $this->SuccessResponse(['message'=>['Successfully deleted']],200);
    }
    public function UnFlag($id){
        $Casher=Casher::findOrfail($id);
        if($Casher->isflaged==1){
        $Casher->isflaged=0;
        $Casher->save();
        $RequestItemFolder=RequestItemFolder::where('state',0)->where('chaser_id',$id)->first();
        if($RequestItemFolder){
            $storeRequest=storeRequest::where('folder_id',$RequestItemFolder->id)->get();
            foreach($storeRequest as $req){
                $item=item::findOrfail($req->item_id);
                $item->sold+=$req->amount;
                $item->save();
                $reporttr=reporttr::where('items',$item->id)->where('amount',$req->amount)->where('type',1)->latest()->first();
                $reporttr->state=1;
                $reporttr->save();
            }
        }
    }
        return $this->SuccessResponse(['message'=>['Successfully deleted']],200);
    }
    public function deleteOrder($id){
        $Casher=Casher::findOrfail($id);
        $Casher->delete();
        
        return $this->SuccessResponse(['message'=>['Successfully deleted']],200);
    }
}
