<?php

namespace App\Http\Controllers\User;

use Exception;
use App\Models\User;
use App\Models\branch;
use App\Models\Salary;
use App\Models\Credit;
use App\Models\UsersStatus;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use App\Services\AuthService;
use App\Http\Controllers\Controller;
use App\Models\UserLoginHistory;
use App\Http\Controllers\User\UserRule;
use Illuminate\Encryption\Encrypter; 
class UserController extends Controller
{
    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('sanitize')->only(['register']);
    // }og in a user
    public function GetCredit(Request $request){
        $holder=[];
        
        $given=[0];
        if($request->isfilter){
            $given=[0,1];
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>=',$now],
                ['created_at','<',$after]
            ];
        }
        $credits = Credit::where('money', '>', 0)->where($holder)
    ->where(function ($query)use($given) {
        $query->where('state', 0)  // If state is 0, get all with money > 0
              ->orWhere(function ($subQuery)use($given) {
                  // If state is in [4, 5, 6], check if 'given' is 0
                  $subQuery->whereIn('state', [4, 5, 6])
                           ->whereIn('given', $given);
              });
    })
    ->with('casher', 'waiter', 'user')
    ->paginate(50);
    return $credits;

    }
    public function GetCreditHouse(){
        return Credit::where('money','>',0)->where('given',0)->where('state',4)->with('user','waiter')->paginate(50);
    }
    public function SearchCredit(Request $request){
        return Credit::where([['full_name','like','%'.$request->search.'%','or'],['phone_number','like','%'.$request->search.'%','or']])->where('money','>',0)->where('given',0)->whereIn('state',[0,4,5,6])->with('user','waiter')->paginate(50);

    }
    public function DeleteCredit($id){
        $credit1=Credit::findorfail($id);
        if($credit1->state>0){
        $user=User::findOrfail($credit1->user_id);
        $user->credit-=$credit1->money;
        $user->save();
        }
        $credit1->delete();
        return 'success';
    }
    public function createCredit(Request $request){
        $this->validate($request,UserRule::CreditstoreRule);
        $credit1=new Credit;
        $credit1->id=Str::uuid();
        $user_holder='';
        $credit1->money=$request->credit;
        if(!$request->user){
            if($request->isgift){
                $credit1->waiter=$request->waiter;
                $credit1->user_id=$request->waiter;
                $credit1->state=4;
                $credit1->phone_number=$request->phone_number;
                $credit1->full_name=$request->full_name;
                }else{
                    $credit1->phone_number=$request->phone_number;
                    $credit1->full_name=$request->full_name;
                    $credit1->waiter=$request->waiter;
                    $credit1->state=0;
                }
           
        }else{
            $user_holder=User::findOrfail($request->user);
            $user_holder->credit+=$request->credit;
            $user_holder->save();
            $credit1->user_id=$request->user;
            if( $user_holder->role=='Waiter')
            $credit1->state=5;
            else
            $credit1->state=6;
        }
        $credit1->casher=Auth::user()->id;
       
        $credit1->save();
        if($request->waiter){
            $holder=User::findOrfail($request->waiter);
            $credit1['waiter']=$holder;
        }
        if($user_holder){
            $credit1['user']=$user_holder;
        }
        $credit1['casher']=Auth::user();
        return $credit1;
    }
    public function updateCredit(Request $request){
        $credit1=Credit::findorfail($request->id);
        $user_holder='';
        $this->validate($request,UserRule::CreditstoreRule);
        if($credit1->state<5){
            if($request->isgift){
                $credit1->waiter=$request->waiter;
                $credit1->user_id=$request->waiter;
                $credit1->state=4;
                $credit1->phone_number=$request->phone_number;
                $credit1->full_name=$request->full_name;
                }else{
                    $credit1->phone_number=$request->phone_number;
                    $credit1->full_name=$request->full_name;
                    $credit1->waiter=$request->waiter;
                    $credit1->state=0;
                }
           
        }else{
            $user_holder=User::findOrfail($request->user);
            $user_holder->credit+=$request->credit-$credit1->money;
            $user_holder->save();
            $credit1->user_id=$request->user;
            if( $user_holder->role=='Waiter')
            $credit1->state=5;
            else
            $credit1->state=6;
        }
        $credit1->money=$request->credit;
        $credit1->casher=Auth::user()->id;
        $credit1->save();

        if($credit1->state==5){
            $holder=User::findOrfail($request->waiter);
            $credit1['waiter']=$holder;
        }
        if($user_holder){
            $credit1['user']=$user_holder;
        }
        $credit1['casher']=Auth::user();
        return $credit1;
    }
    public function PayCredit(Request $request){
        $credit=Credit::findorfail($request->id);
        $credit->money-=$request->money;
        $credit->paid+=$request->money;
        $credit->casher=Auth::user()->id;
        $credit->save();
        $credit1=new Credit;
        $credit1->id=Str::uuid();
        $credit1->user_id=$credit->user_id;
        $credit1->money=$credit->money;
        $credit1->paid=$request->money;
        $credit1->phone_number=$credit->phone_number;
        $credit1->full_name=$credit->full_name;
        // $credit1->paid=$credit->paid;
        $credit1->casher=Auth::user()->id;
        $credit1->state=1;
        $credit1->save();
    }
    public function UserProfile(){
        $user=User::where('id',Auth::user()->id)->with('branch')->first();
        return $this->SuccessResponse($user,200);
    }
    public function UserProfileWaitre(){
        $user=User::where('state',1)->wherein('role',['Waitre','Waiter'])->get();
        return $this->SuccessResponse($user,200);
    }
    public function UserProfilechef(){
        $user=User::where('state',1)->wherein('role',['Chef','Chef'])->get();
        return $this->SuccessResponse($user,200);
    }
    public function updateUserProfile(Request $request){
        $user=User::findOrfail(Auth::user()->id);
        $branch=branch::where('user',$user->id)->first();
     $this->validate($request,UserRule::UpdateUsersRule);
     $user=(new User)->UpdateUser($request,$user,User::UpdateUserProfile);
     return $this->SuccessResponse($user,200); 
    }
    public function GetUserProfile($id){
        $user=User::where('id',$id)->with('branch')->first();
        return $this->SuccessResponse($user,200);
    }
    public function changephonenumber(Request $request){
        $user=User::findOrfail(Auth::user()->id);
        $this->validate($request,UserRule::ChangePhoneNumber($user->id));
        if(Hash::check($request->password, $user->password)){
        $user->phone_number=$request->phone_number;
        $user->save();
        return $this->SuccessResponse($user,200);
        }
        return $this->ErrorResponse(['password'=>['wrong password !']],422);

    }
    public function changeUsername(Request $request){
        $user=User::findOrfail(Auth::user()->id);
        $this->validate($request,UserRule::changeUsername($user->id));
        if(Hash::check($request->password, $user->password)){
        $user->username=$request->username;
        $user->save();
        return $this->SuccessResponse($user,200);
        }
        return $this->ErrorResponse(['password'=>['wrong password !']],422);

    }
    public function changeUserPassword(Request $request){
        $user=User::findOrfail(Auth::user()->id);
        $this->validate($request,UserRule::changePassword);
        if(Hash::check($request->old_password, $user->password)){
        $user->password= Hash::make($request->password);
        $user->save();
        return $this->SuccessResponse($user,200);
        }
        return $this->ErrorResponse(['password'=>['wrong password !']],422);

    }
    public function index(){
        $user=User::where('role','!=','Admin')->where('state','!=',-2)->with('branch')->paginate(200);
        $salary=User::where('role','!=','Admin')->where('state','!=',-2)->sum('salary');
       return $this->SuccessResponse([$user,$salary],200);
    }
    public function SearchUsers(Request $request){
        $user=User::where('role','!=','Admin')->where('username','like','%'.$request->username.'%')->with('branch')->get();
       return $this->SuccessResponse($user,200);
    }
    public function showUser($id){
        $user=User::where('id',$id)->where('role','manager')->with('branch')->first();
       return $this->SuccessResponse($user,200);
    }
    public function Pay($id){
        $user=User::findorfail($id);
        $left=$user->salary-$user->credit;
        $salary=$left;
        if($left<0){
            $salary=0;
            $user->credit=$left*-1;
        }else{
            $user->credit=0;
        }
        $user->save();
        (new Salary)->StoreSalary($user->id,$salary);
       }
   public function Remark(Request $request,$id){
    $user=User::findorfail($id);
    if($user->remark){
        $holder=json_decode($user->remark);
        $holder[]=['remark'=>$request->remark,'date'=>Carbon::now(),'menu'=>$request->menu,'time'=>$request->time];
        $user->remark=json_encode($holder);
    }else{
        $user->remark=json_encode([['remark'=>$request->remark,'date'=>Carbon::now(),'menu'=>$request->menu,'time'=>$request->time]]);
    }
    $user->save();
   }
   public function GetSalary(){
    return Salary::with('user')->orderBy('created_at','desc')->paginate(50);
   }
   public function Store(Request $request){
        $this->validate($request,UserRule::RegisterEmployeRule);
        $user=(new User)->StoreEmploye($request,$request->role);
        $holder=['title'=>$request->title,'location'=>$request->location,'user'=>$user->id];
         $branch=(new branch)->Storebranch($holder);
        $user['branch']=$branch;
        return $this->SuccessResponse($user,200); 
   }
   public function ChangePassword(Request $request,$id){
       $user=User::findorfail($id);
    $this->validate($request,UserRule::ChangeEmployePasswordRule);
    $user->password=Hash::make($request->password);
    $user->save();
    return $this->SuccessResponse('success',200); 

   }
   public function Update(Request $request,$id){
       $user=User::findOrfail($id);
       $branch=branch::where('user',$user->id)->first();
    $this->validate($request,UserRule::RegisterUpdateEmployeRule($id));
    $usr=(new User)->UpdateUser($request,$user,User::UpdateEmployeProfile);
    $holder=['title'=>$request->title,'location'=>$request->location,'user'=>$user->id];
     $branch=(new branch)->Updatebranch($request,$branch,branch::Updatebranch);
    $user['branch']=$branch;
    return $this->SuccessResponse($user,200); 
   }
   public function GetBranches(){
       $branch=branch::where('state',1)->get();
       return $this->SuccessResponse($branch,200);
   }
   public function GetBranchesWithAdmin(){
    $branch=branch::where('state',1)->where('role','!=','Admin')->get();
    return $this->SuccessResponse($branch,200);
} 
public function Delete($id){
    $user=User::findorfail($id);
    $branch=branch::where('user',$user->id)->first();
    $branch->state=-1;
    $branch->title=$branch->title.' Deleted Branch';
    $branch->save();
    $user->username=$user->username.' Deleted Acount';
    $user->phone_number=$user->phone_number.' Deleted Acount';
    $user->state=-2;
    $user->save();
}
public function DActivet($id){
    $user=User::findorfail($id);
    $branch=branch::where('user',$user->id)->first();
    $user->state=-1;
    $branch->state=-1;
    $branch->save();
    $user->save();
}
public function Activet($id){
    $user=User::findorfail($id);
    $branch=branch::where('user',$user->id)->first();
    $user->state=1;
    $branch->state=1;
    $branch->save();
    $user->save();
}
}