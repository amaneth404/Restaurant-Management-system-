<?php

namespace App\Http\Controllers\Expense\ExpenseRules;


class ExpenseRules
{
    const ExpenseStoreRule=[
        'description'=>'required',
        'amount'=>'required',
    ];
    public static function ExpenseUpdateRule($id){
        return [
        'description'=>'required',
        'amount'=>'required',
    ];
}
}


