<?php

namespace App\Http\Controllers\Bank;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\bank;
use App\Models\Casher;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Bank\BankRules\BankRules;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
class BankController extends Controller
{
    public function index(){
        $bank=bank::where('state',1)->orderBy('created_at', 'desc')->paginate(200);
        return $this->SuccessResponse($bank,200);
    }
    public function indexStored(Request $request){
        $holder=[];
        
        $given=[0];
        if($request->isfilter){
            $given=[0,1];
            $now = Carbon::parse($request->from)->format('Y-m-d H:i:s');
            $after = Carbon::parse($request->to)->format('Y-m-d H:i:s');
            $now=Carbon::parse($now,'Africa/Nairobi')->setTimezone('UTC');
            $after=Carbon::parse($after,'Africa/Nairobi')->setTimezone('UTC');
            $holder = [
                ['created_at','>=',$now],
                ['created_at','<',$after]
            ];
        }
       return  Casher::where('isflaged',0)->where($holder)->where('state',-10)->whereIn('given',$given)->whereIn('w_given',$given)->with('waiter','user','bank')->wherenotnull('bank')->paginate(200);
    }
    public function Bankdestroy($id){
        $Casher=Casher::findorfail($id);
        $Casher->delete();
        return 'success';
    }
    public function UpdateBank(Request $request){
        
        $Casher=new Casher;
        $Casher->id=Str::uuid();
       
        $Casher->folder_id=Str::uuid();
        $Casher->credit=0;
       
        $Casher->is_gift=0;
        $Casher->index_holder=0;
        $Casher->orders= '';
        $Casher->waiter=$request->user_id;
        $Casher->table_name=0;
        $Casher->amount=1;
        $Casher->aut_id=Auth::user()->id;
        $Casher->state=-10;
        $Casher->price=0;
        $Casher->tokichen=0;
        $Casher->bank=$request->bank_id;
        $Casher->bank_money=$request->money;
        $Casher->save();
        $Casher['bank']=bank::findOrfail($request->bank_id);
        $Casher['waiter']=User::findOrfail($request->user_id);
        return $Casher;
    }
    public function EditBank(Request $request,$id){
        $Casher=Casher::findOrfail($id);
        $Casher->waiter=$request->user_id;
        $Casher->aut_id=Auth::user()->id;
        $Casher->bank=$request->bank_id;
        $Casher->bank_money=$request->money;
        $Casher->save();
        $Casher['bank']=bank::findOrfail($request->bank_id);
        $Casher['waiter']=User::findOrfail($request->user_id);
        return $Casher;

     }
    public function Search(Request $request){
        $bank=bank::where('name','like','%'.$request->search.'%')->whereIn('state',[1,-1])->orderBy('created_at', 'desc')->paginate(200);
        return $this->SuccessResponse($bank,200);
    }
    public function store(Request $request){        
        $this->validate($request,BankRules::BankStoreRule);
         $bank=(new bank)->Storebank($request);
        return $this->SuccessResponse($bank,200);
    }
    public function update(Request $request,$id){
        $bank=bank::findOrfail($id);
        $this->validate($request,BankRules::BankUpdateRule($bank->id));
        $bank=(new bank)->Updatebank($request,$bank,bank::Updatebank);
        return $this->successResponse($bank,200);
    }
}
